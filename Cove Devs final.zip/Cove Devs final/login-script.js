const wrapper = document.querySelector('.wrapper');
const signUpLink = document.querySelector('.signUp-link');
const signInLink = document.querySelector('.signIn-link');

const toggleLogin = document.querySelector('.toggle-login');
const toggleSignup = document.querySelector('.toggle-signup');
const close = document.querySelector('.close');

signUpLink.addEventListener('click', () =>{
    wrapper.classList.toggle('show-sign');
    wrapper.classList.add('show-bg');
});

signInLink.addEventListener('click', () =>{
    wrapper.classList.toggle('show-sign');
    wrapper.classList.add('show-bg');
});

toggleLogin.addEventListener('click', () =>{
    toggleLogin.classList.toggle('active');
    wrapper.classList.toggle('active');
});

close.addEventListener('click', () =>{
    toggleLogin.classList.toggle('active');
    wrapper.classList.toggle('active');
    wrapper.classList.remove('show-bg');
});

//join
toggleSignup.addEventListener('click', () =>{
    toggleSignup.classList.toggle('active');
    wrapper.classList.toggle('active');
});

close.addEventListener('click', () =>{
    toggleSignup.classList.toggle('active');
    // wrapper.classList.toggle('active');
    wrapper.classList.remove('show-bg');
});

$("#submit").click(function(){
    alert("here");
});

function validateLog(event){
    event.preventDefault();
    
    if(localStorage){
        //debugger;
        let username = document.getElementById("username").value;
        let inputPassword = document.getElementById("pass").value;
        let usernameData = localStorage.getItem("email");
        let userpassword = localStorage.getItem("pass");
                
        var total = 0;
            
        if(userpassword == inputPassword && usernameData == username)
        {
            alert("Correct password");
            //location.href = '';
            window.location.replace("home.html");
        }
        else{
            alert("incorrect username or password");
            return;
        }  
    }
    else{
        alert("System Error ");
    }
}